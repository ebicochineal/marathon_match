// C++11
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("inline")

#include <cmath>
#include <string>
#include <array>
#include <vector>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <limits>
#include <queue>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <bitset>
#include <time.h>
#include <sys/timeb.h>
using namespace std;

template<class F, class S> string in_v_to_str (const pair<F, S> v);
template<class F, class S> string v_to_str (const pair<F, S> v);
string in_v_to_str (const char v) { return "'" + string{v} + "'"; }
string in_v_to_str (const char* v) { return "\"" + string(v) + "\""; }
string in_v_to_str (const string v) { return "\"" + v + "\""; }
template<class T> string in_v_to_str (const T v) { stringstream ss; ss << v; return ss.str(); }
template<class T> string v_to_str (const T v) { stringstream ss; ss << v; return ss.str(); }
template<class T, size_t N> string v_to_str (const array<T, N>& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << in_v_to_str(v[i]) << ", "; } ss << in_v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[]"; } return ss.str(); }
template<class T, size_t N> string v_to_str (const array< array<T, N>, N >& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << v_to_str(v[i]) << ", "; } ss << v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[-]"; } return ss.str(); }
template<class T> string v_to_str (const vector<T>& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << in_v_to_str(v[i]) << ", "; } ss << in_v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[]"; } return ss.str(); }
template<class T> string v_to_str (const vector< vector<T> >& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << v_to_str(v[i]) << ", "; } ss << v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[-]"; } return ss.str(); }
template<class T> string v_to_str (const set<T>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class K, class V> string v_to_str (const map<K, V>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i.first) << " : " << in_v_to_str(i.second) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class T> string v_to_str (const unordered_set<T>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class K, class V> string v_to_str (const unordered_map<K, V>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i.first) << " : " << in_v_to_str(i.second) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class F, class S> string in_v_to_str (const pair<F, S> v) { stringstream ss; ss << "<" << v_to_str(v.first) << ", " << v_to_str(v.second) << ">"; return ss.str(); }
template<class F, class S> string v_to_str (const pair<F, S> v) { stringstream ss; ss << "<" << v_to_str(v.first) << ", " << v_to_str(v.second) << ">"; return ss.str(); }
string print () { return ""; }
template<typename F, typename... R> string print (const F& f, const R& ...r) { stringstream ss; ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); } return ss.str(); }

template<typename F, typename... R> void pdebug (const F& f, const R& ...r) {
    stringstream ss;
    ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); }
    cerr << "<cerr>" << ss.str() << "</cerr>" << endl;
}

template<typename F, typename... R> void fdebug (const F& f, const R& ...r) {
    stringstream ss;
    ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); }
    cerr << "<cerrfile>" << ss.str() << "</cerrfile>" << endl;
}

template<typename F, typename... R> void tdebug (const F& f, const R& ...r) {
    stringstream ss;
    ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); }
    cerr << "<cerr>[time]" << ss.str() << "</cerr>" << endl;
}

struct e512pos {
public:
    int x;
    int y;
    e512pos () { this->x = 0; this->y = 0; }
    e512pos (int x, int y) {
        this->x = x;
        this->y = y;
    }
    e512pos operator + (const e512pos& t) { return e512pos(this->x + t.x, this->y + t.y); }
    e512pos operator - (const e512pos& t) { return e512pos(this->x - t.x, this->y - t.y); }
    bool operator == (const e512pos& t) const { return this->x == t.x && this->y == t.y; }
};
namespace std {
    template <> class hash<e512pos> {
    public:
        size_t operator()(const e512pos& t) const{ return hash<int>()(t.x<<16) | hash<int>()(t.y); }
    };
}
ostream& operator << (ostream& os, const e512pos& p) {
    os << "(" << p.x << ", " << p.y << ")";
    return os;
};

class StopWatch {
public:
    int starts;
    int startm;
    int tstarts = 0;
    int tstartm = 0;
    struct timeb timebuffer;
    StopWatch () {
        ftime(&this->timebuffer);
        this->starts = this->timebuffer.time;
        this->startm = this->timebuffer.millitm;
    }
    inline void stop () {
        ftime(&this->timebuffer);
        this->tstarts = this->timebuffer.time;
        this->tstartm = this->timebuffer.millitm;
    }
    inline void resume () {
        ftime(&this->timebuffer);
        this->starts += this->timebuffer.time - this->tstarts;
        this->startm += this->timebuffer.millitm - this->tstartm;
    }
    inline int get_milli_time () {
        ftime(&this->timebuffer);
        return (this->timebuffer.time - this->starts) * 1000 + (this->timebuffer.millitm - this->startm);
    }
};

inline uint32_t xrnd() {
    static uint32_t y = 2463534242;
    y = y ^ (y << 13);
    y = y ^ (y >> 17);
    return y = y ^ (y << 5);
}

struct Grid {
    array< array<int, 30>, 30 > g;
    array<int, 120> bp;
    
    array<e512pos, 5> bp_pos;
    array<int, 5> bp_dir;
    
    int N, B, V;
    Grid () {}
    Grid (array< array<int, 30>, 30 >& ig, int N, int B, int V) {
        this->init(ig, N, B, V);
    }
    void init (array< array<int, 30>, 30 >& ig, int N, int B, int V) {
        this->N = N;
        this->B = B;
        this->V = V;
        for (int y = 0; y < this->N; ++y) {
            for (int x = 0; x < this->N; ++x) {
                this->g[y][x] = ig[y][x];
            }
        }
        
        for (int i = 0; i < this->N*4; ++i) { this->bp[i] = i % this->N + (i / this->N) * 30; }
    }
    
    int ra, rb;
    void random_swap_bp () {
        this->ra = xrnd() % this->B;
        this->rb = this->B + xrnd() % (this->N*4-this->B);
        swap(this->bp[this->ra], this->bp[this->rb]);
    }
    void swap_back_bp () {
        swap(this->bp[this->ra], this->bp[this->rb]);
    }
    
    
    int sim () {
        // /\.*
        static int dtable[4][8] = {
            { 1,-1, 0, 0, 1,-1, 0, 0},
            {-1, 1, 0, 0,-1, 1, 0, 0},
            { 1,-1, 0, 0, 1,-1, 0, 0},
            {-1, 1, 0, 0,-1, 1, 0, 0}
        };
        static int ptable[8] = {1, 1, 0, this->V, 1, 1, 0, this->V};
        static int gtable[8] = {1, 0, 2, 3, 5, 4, 6, 7};
        
        static array< array<int, 30>, 30 > ctg;
        static array< array<int, 30>, 30 > tg;
        static vector<e512pos> v;
        
        int score = 0;
        for (int y = 0; y < this->N; ++y) {
            for (int x = 0; x < this->N; ++x) {
                tg[y][x] = this->g[y][x];
                if(this->g[y][x] > 3) {
                    ctg[y][x] = 16;
                } else {
                    ctg[y][x] = 0;
                }
            }
        }
        
        for (int i = 0; i < this->B; ++i) {
            int a = this->bp[i] / 30;
            int b = this->bp[i] % 30;
            this->bp_dir[i] = (a+2) % 4;
            if (a == 0) {
                this->bp_pos[i].y = 0;
                this->bp_pos[i].x = b;
            }
            if (a == 1) {
                this->bp_pos[i].y = b;
                this->bp_pos[i].x = this->N-1;
            }
            if (a == 2) {
                this->bp_pos[i].y = this->N-1;
                this->bp_pos[i].x = this->N-1-b;
            }
            if (a == 3) {
                this->bp_pos[i].y = this->N-1-b;
                this->bp_pos[i].x = 0;
            }
        }
        
        
        bool f = true;
        
        
        while (f) {
            v.clear();
            // dire score
            for (int i = 0; i < this->B; ++i) {
                const int y = this->bp_pos[i].y;
                const int x = this->bp_pos[i].x;
                const int d = this->bp_dir[i];
                const int t = tg[y][x];
                this->bp_dir[i] = (this->bp_dir[i] + dtable[d][t] + 4) % 4;
                score += ptable[t];
                
                ctg[y][x] += 1;
                v.emplace_back(e512pos(x, y));
            }
            
            // grid dire
            
            for (int i = 0; i < this->B; ++i) {
                const int y = this->bp_pos[i].y;
                const int x = this->bp_pos[i].x;
                const int d = this->bp_dir[i];
                
                if (ctg[y][x] > 0 && ctg[y][x] < 16) {
                    tg[y][x] = gtable[tg[y][x]];
                }
            }
            
            for (auto&& i : v) {
                ctg[i.y][i.x] = ctg[i.y][i.x] >= 16 ? 16 : 0;
            }
            
            // move
            for (int i = 0; i < this->B; ++i) {
                const int y = this->bp_pos[i].y;
                const int x = this->bp_pos[i].x;
                const int d = this->bp_dir[i];
                
                if (d == 0) {
                    this->bp_pos[i].y -= 1;
                    if (this->bp_pos[i].y < 0) { f = false; }
                }
                if (d == 1) {
                    this->bp_pos[i].x += 1;
                    if (this->bp_pos[i].x >= this->N) { f = false; }
                }
                if (d == 2) {
                    this->bp_pos[i].y += 1;
                    if (this->bp_pos[i].y >= this->N) { f = false; }
                }
                if (d == 3) {
                    this->bp_pos[i].x -= 1;
                    if (this->bp_pos[i].x < 0) { f = false; }
                }
            }
            
        }
        for (int i = 0; i < this->B; ++i) {
            const int y = this->bp_pos[i].y;
            const int x = this->bp_pos[i].x;
            if (this->bp_pos[i].y < 0) { continue; }
            if (this->bp_pos[i].x >= this->N) { continue; }
            if (this->bp_pos[i].y >= this->N) { continue; }
            if (this->bp_pos[i].x < 0) { continue; }
            const int d = this->bp_dir[i];
            const int t = tg[y][x];
            this->bp_dir[i] = (this->bp_dir[i] + dtable[d][t] + 4) % 4;
            score += ptable[t];
            
            ctg[y][x] += 1;
            v.emplace_back(e512pos(x, y));
        }
        
        return score;
    }
    
    
};
class MM {
public:
    StopWatch sw;
    int N, B, bonusValue;
    Grid bestgrid;
    array< array<int, 30>, 30 > ig;
    
    array<int, 5> output_b;
    array< array<int, 30>, 30 > output_g;
    
    MM () { this->sw = StopWatch(); }
    void input () {
        cin >> this->N;
        cin >> this->B;
        cin >> this->bonusValue;
        
        int xcnt = 0;
        for (int r = 0; r < this->N; r++) {
            for (int c = 0; c < this->N; c++) {
                char t;
                cin >> t;
                if (t == '/' ) { this->ig[r][c] = 0+4; }
                if (t == '\\') { this->ig[r][c] = 1+4; }
                if (t == '.' ) { this->ig[r][c] = 2; }
                if (t == '*' ) { this->ig[r][c] = 3+4; }
                if (t != '.') { xcnt += 1;}
                getchar();
            }
        }
        
        pdebug(N, B, bonusValue);
        
    }
    void output () {
        for (int i = 0; i < this->B; ++i) {
            int a = this->bestgrid.bp[i] / 30;
            int b = this->bestgrid.bp[i] % 30;
            if (a == 0) { cout << print(-1, b) << endl; }
            if (a == 1) { cout << print(b, this->N) << endl; }
            if (a == 2) { cout << print(this->N, this->N-1-b) << endl; }
            if (a == 3) { cout << print(this->N-1-b, -1) << endl; }
            
        }
        
        
        char cells[] = {'/', '\\', '.', '*'};
        for (int r = 0; r < this->N; r++) {
            for (int c = 0; c < this->N; c++) {
                cout << cells[this->bestgrid.g[r][c] % 4] << endl;
            }
        }
    }
    void solve () {
        Grid grid(this->ig, this->N, this->B, this->bonusValue);
        int cnt = 0;
        double bestscore = 0;
        this->bestgrid = grid;
        this->bestgrid = this->maximize_sa(this->bestgrid, bestscore, cnt, 4000, 24.0, 0.0);
        pdebug(bestscore);
        this->bestgrid = this->maximize_sa(this->bestgrid, bestscore, cnt, 4000, 24.0, 0.0);
        pdebug(bestscore);
        this->bestgrid = this->maximize_sa(this->bestgrid, bestscore, cnt, 1000, 32.0, 0.0);
        pdebug(bestscore);
        // this->bestgrid = this->maximize_sa(this->bestgrid, bestscore, 2000, 24.0, 0.0);
        pdebug(cnt, this->sw.get_milli_time());
        
    }
    
    
    Grid maximize_sa (Grid v, double& refscore, int& cnt, int etime, double stemp = 256.0, double etemp = 0.0) {
        StopWatch sw;
        int stime = 0;
        const double satime = etime - stime;
        int ntime = stime;
        Grid bestv = v;
        double bestscore = v.sim();
        double lastscore = bestscore;
        const int64_t R = 1000000000;
        
        int dcnt = 0;
        
        int m = this->N > 20 ? 25000 : 50000;
        
        while (true) {
            {
                ntime = sw.get_milli_time();
                if (ntime >= etime) { break; }
                v.random_swap_bp();
                
                double tmpscore = v.sim();
                const double temp = stemp*2 + (etemp - stemp*2) * (double)(ntime-stime) / satime;
                const double probability = exp((tmpscore - lastscore) / temp);
                const bool FORCE_NEXT = probability > (double)(xrnd() % R) / R;
                if (tmpscore > lastscore || FORCE_NEXT) {
                    lastscore = tmpscore;
                    dcnt += 1;
                    if (tmpscore > bestscore) {
                        bestscore = tmpscore;
                        bestv = v;
                        dcnt = 0;
                    }
                } else {
                    v.swap_back_bp();
                }
                cnt += 1;
            }
            for (int i = 0; i < 32; ++i) {
                ntime = sw.get_milli_time();
                if (ntime >= etime) { break; }
                
                int x = xrnd()%this->N;
                int y = xrnd()%this->N;
                int t = v.g[y][x];
                if(v.g[y][x] <= 2) {
                    v.g[y][x] = (v.g[y][x] + 1 + xrnd()%2)%3;
                } else {
                    continue;
                }
                
                double tmpscore = v.sim();
                const double temp = stemp + (etemp - stemp) * (double)(ntime-stime) / satime;
                const double probability = exp((tmpscore - lastscore) / temp);
                const bool FORCE_NEXT = probability > (double)(xrnd() % R) / R;
                if (tmpscore > lastscore || FORCE_NEXT) {
                    lastscore = tmpscore;
                    dcnt += 1;
                    if (tmpscore > bestscore) {
                        bestscore = tmpscore;
                        bestv = v;
                        dcnt = 0;
                    }
                    
                    
                } else {
                    v.g[y][x] = t;
                }
                cnt += 1;
            }
            if (dcnt > m) {
                v = bestv;
                dcnt = 0;
                lastscore = bestscore;
            }
            
        }
        refscore = bestscore;
        return bestv;
    }
};

int main () {
    // cin.tie(0);
    // ios::sync_with_stdio(false);
    
    MM mm;
    mm.input();
    mm.solve();
    mm.output();
    cout.flush();
    return 0;
}