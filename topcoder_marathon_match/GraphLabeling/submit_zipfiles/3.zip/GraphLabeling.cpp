#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("inline")

#include <cmath>
#include <string>
#include <array>
#include <vector>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <limits>
#include <queue>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <bitset>
    #include <random>
#include <time.h>
#include <sys/timeb.h>
using namespace std;

template<class F, class S> string in_v_to_str (const pair<F, S> v);
template<class F, class S> string v_to_str (const pair<F, S> v);
string in_v_to_str (const char v) { return "'" + string{v} + "'"; }
string in_v_to_str (const char* v) { return "\"" + string(v) + "\""; }
string in_v_to_str (const string v) { return "\"" + v + "\""; }
template<class T> string in_v_to_str (const T v) { stringstream ss; ss << v; return ss.str(); }
template<class T> string v_to_str (const T v) { stringstream ss; ss << v; return ss.str(); }
template<class T, size_t N> string v_to_str (const array<T, N>& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << in_v_to_str(v[i]) << ", "; } ss << in_v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[]"; } return ss.str(); }
template<class T, size_t N> string v_to_str (const array< array<T, N>, N >& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << v_to_str(v[i]) << ", "; } ss << v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[-]"; } return ss.str(); }
template<class T> string v_to_str (const vector<T>& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << in_v_to_str(v[i]) << ", "; } ss << in_v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[]"; } return ss.str(); }
template<class T> string v_to_str (const vector< vector<T> >& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << v_to_str(v[i]) << ", "; } ss << v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[-]"; } return ss.str(); }
template<class T> string v_to_str (const set<T>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class K, class V> string v_to_str (const map<K, V>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i.first) << " : " << in_v_to_str(i.second) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class T> string v_to_str (const unordered_set<T>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class K, class V> string v_to_str (const unordered_map<K, V>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i.first) << " : " << in_v_to_str(i.second) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class F, class S> string in_v_to_str (const pair<F, S> v) { stringstream ss; ss << "<" << v_to_str(v.first) << ", " << v_to_str(v.second) << ">"; return ss.str(); }
template<class F, class S> string v_to_str (const pair<F, S> v) { stringstream ss; ss << "<" << v_to_str(v.first) << ", " << v_to_str(v.second) << ">"; return ss.str(); }
string print () { return ""; }
template<typename F, typename... R> string print (const F& f, const R& ...r) { stringstream ss; ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); } return ss.str(); }

template<typename F, typename... R> void pdebug (const F& f, const R& ...r) {
    stringstream ss;
    ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); }
    cerr << "<cerr>" << ss.str() << "</cerr>" << endl;
}

template<typename F, typename... R> void fdebug (const F& f, const R& ...r) {
    stringstream ss;
    ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); }
    cerr << "<cerrfile>" << ss.str() << "</cerrfile>" << endl;
}

template<typename F, typename... R> void tdebug (const F& f, const R& ...r) {
    stringstream ss;
    ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); }
    cerr << "<cerr>[time]" << ss.str() << "</cerr>" << endl;
}



struct e512pos {
public:
    int x;
    int y;
    e512pos () { this->x = 0; this->y = 0; }
    e512pos (int x, int y) {
        this->x = x;
        this->y = y;
    }
    e512pos operator + (const e512pos& t) { return e512pos(this->x + t.x, this->y + t.y); }
    e512pos operator - (const e512pos& t) { return e512pos(this->x - t.x, this->y - t.y); }
    bool operator == (const e512pos& t) const { return this->x == t.x && this->y == t.y; }
};
namespace std {
    template <> class hash<e512pos> {
    public:
        size_t operator()(const e512pos& t) const{ return t.x<<16 | t.y; }
    };
}
ostream& operator << (ostream& os, const e512pos& p) {
    os << "(" << p.x << ", " << p.y << ")";
    return os;
};

class StopWatch {
public:
    int starts;
    int startm;
    int tstarts = 0;
    int tstartm = 0;
    struct timeb timebuffer;
    StopWatch () {
        ftime(&this->timebuffer);
        this->starts = this->timebuffer.time;
        this->startm = this->timebuffer.millitm;
    }
    inline void stop () {
        ftime(&this->timebuffer);
        this->tstarts = this->timebuffer.time;
        this->tstartm = this->timebuffer.millitm;
    }
    inline void resume () {
        ftime(&this->timebuffer);
        this->starts += this->timebuffer.time - this->tstarts;
        this->startm += this->timebuffer.millitm - this->tstartm;
    }
    inline int get_milli_time () {
        ftime(&this->timebuffer);
        return (this->timebuffer.time - this->starts) * 1000 + (this->timebuffer.millitm - this->startm);
    }
};

inline uint32_t xrnd() {
    static uint32_t y = 2463534242;
    y = y ^ (y << 13);
    y = y ^ (y >> 17);
    return y = y ^ (y << 5);
}

void output (vector<int> v) {
    ostringstream out;
    for (auto&& i : v) { out << i << " "; }
    cout << out.str() << endl;
    cout.flush();
}

void solve (int N, int edges, vector< vector<int> >& g, vector<int>& ret, int& score) {
    vector<int> v(N, -1);
    unordered_set<int> us;
    bitset<2085050> bvs;
    bitset<2085050> bes;
    int m = 0;
    
    
    vector<int> indexs;
    for(int i = 0; i < N; i++) { indexs.emplace_back(i); }
    
    // mt19937 mt(xrnd());
    // shuffle(indexs.begin(), indexs.end(), mt);
    sort(indexs.begin(), indexs.end(), [g](const int& a, const int& b) { return g[a].size() > g[b].size(); });
    
    bool t = true;
    double d = edges > 50000 ? 0.8 : 0.5;
    
    for (auto&& i : indexs) {
    // for (int z = 0; z < indexs.size(); ++z) {
    //     int i = indexs[z];
    //     if (i >= indexs.size()-5) { d = 0; }
        if (t) {
            bvs[0] = true;
            v[i] = 0;
            t = false;
            continue;
        }
        // for (int j = m; j < 2085050; ++j) {
        for (int j = m*d; j < 2085050; ++j) {
            if (bvs[j]) { continue; }
            bool f = false;
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    if (bes[abs(j-v[k])]) {
                        f = true;
                        break;
                    }
                }
            }
            if (f) { continue; }
            
            us.clear();
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    if (us.find(abs(j-v[k])) != us.end()) {
                        f = true;
                        break;
                    }
                    us.emplace(abs(j-v[k]));
                }
            }
            
            if (f) { continue; }
            bvs[j] = true;
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    bes[abs(j-v[k])] = true;
                }
            }
            v[i] = j;
            m = max(m, j);
            break;
        }
    }
    
    ret = v;
    score = m;
}

void rndsolve (int N, int edges, vector< vector<int> >& g, vector<int>& ret, int& score) {
    vector<int> v(N, -1);
    unordered_set<int> us;
    bitset<2085050> bvs;
    bitset<2085050> bes;
    int m = 0;
    
    
    vector<int> indexs;
    for(int i = 0; i < N; i++) { indexs.emplace_back(i); }
    
    mt19937 mt(xrnd());
    shuffle(indexs.begin(), indexs.end(), mt);
    // sort(indexs.begin(), indexs.end(), [g](const int& a, const int& b) { return g[a].size() > g[b].size(); });
    
    bool t = true;
    double d = edges > 50000 ? 0.8 :  0.5;
    
    for (auto&& i : indexs) {
    // for (int z = 0; z < indexs.size(); ++z) {
        // int i = indexs[z];
        // if (i >= indexs.size()-5) { d = 0; }
        if (t) {
            bvs[0] = true;
            v[i] = 0;
            t = false;
            continue;
        }
        // for (int j = m; j < 2085050; ++j) {
        for (int j = m*d; j < 2085050; ++j) {
            if (bvs[j]) { continue; }
            bool f = false;
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    if (bes[abs(j-v[k])]) {
                        f = true;
                        break;
                    }
                }
            }
            if (f) { continue; }
            
            us.clear();
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    if (us.find(abs(j-v[k])) != us.end()) {
                        f = true;
                        break;
                    }
                    us.emplace(abs(j-v[k]));
                }
            }
            
            if (f) { continue; }
            bvs[j] = true;
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    bes[abs(j-v[k])] = true;
                }
            }
            v[i] = j;
            m = max(m, j);
            break;
        }
    }
    
    ret = v;
    score = m;
}

void rndsolve2 (int N, int edges, vector< vector<int> >& g, vector<int>& ret, int& score) {
    vector<int> v(N, -1);
    unordered_set<int> us;
    bitset<2085050> bvs;
    bitset<2085050> bes;
    int m = 0;
    
    
    vector<int> indexs;
    for(int i = 0; i < N; i++) { indexs.emplace_back(i); }
    
    mt19937 mt(xrnd());
    // shuffle(indexs.begin(), indexs.end(), mt);
    sort(indexs.begin(), indexs.end(), [g](const int& a, const int& b) { return g[a].size() > g[b].size(); });
    
    bool t = true;
    
    for (auto&& i : indexs) {
    
    // for (int z = 0; z < indexs.size(); ++z) {
    //     int i = indexs[z];
    //     if (i >= indexs.size()-5) { d = 0; }
        double d = 1.0-(xrnd()%11)*0.1;
        if (t) {
            bvs[0] = true;
            v[i] = 0;
            t = false;
            continue;
        }
        // for (int j = m; j < 2085050; ++j) {
        for (int j = m*d; j < 2085050; ++j) {
            if (bvs[j]) { continue; }
            bool f = false;
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    if (bes[abs(j-v[k])]) {
                        f = true;
                        break;
                    }
                }
            }
            if (f) { continue; }
            
            us.clear();
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    if (us.find(abs(j-v[k])) != us.end()) {
                        f = true;
                        break;
                    }
                    us.emplace(abs(j-v[k]));
                }
            }
            
            if (f) { continue; }
            bvs[j] = true;
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    bes[abs(j-v[k])] = true;
                }
            }
            v[i] = j;
            m = max(m, j);
            break;
        }
    }
    
    ret = v;
    score = m;
}

void rndsolve3 (int N, int edges, vector< vector<int> >& g, vector<int>& ret, int& score, vector<int> indexs, StopWatch& sw) {
    vector<int> v(N, -1);
    unordered_set<int> us;
    bitset<2085050> bvs;
    bitset<2085050> bes;
    int m = 0;
    
    bool t = true;
    
    for (auto&& i : indexs) {
    
    // for (int z = 0; z < indexs.size(); ++z) {
    //     int i = indexs[z];
    //     if (i >= indexs.size()-5) { d = 0; }
        double d = 0.8;
        if (t) {
            bvs[0] = true;
            v[i] = 0;
            t = false;
            continue;
        }
        // for (int j = m; j < 2085050; ++j) {
        for (int j = m*d; j < 2085050; ++j) {
            if (bvs[j]) { continue; }
            bool f = false;
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    if (bes[abs(j-v[k])]) {
                        f = true;
                        break;
                    }
                }
            }
            if (f) { continue; }
            
            us.clear();
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    if (us.find(abs(j-v[k])) != us.end()) {
                        f = true;
                        break;
                    }
                    us.emplace(abs(j-v[k]));
                }
            }
            
            if (f) { continue; }
            bvs[j] = true;
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    bes[abs(j-v[k])] = true;
                }
            }
            v[i] = j;
            m = max(m, j);
            break;
        }
        
        if (sw.get_milli_time() > 9500) {
            score = 2085050;
            return;
        }
    }
    
    ret = v;
    score = m;
}
void rndsolve4 (int N, int edges, vector< vector<int> >& g, vector<int>& ret, int& score, vector<int> indexs, StopWatch& sw) {
    vector<int> v(N, -1);
    unordered_set<int> us;
    bitset<2085050> bvs;
    bitset<2085050> bes;
    int m = 0;
    
    bool t = true;
    
    for (auto&& i : indexs) {
    
    // for (int z = 0; z < indexs.size(); ++z) {
    //     int i = indexs[z];
    //     if (i >= indexs.size()-5) { d = 0; }
        double d = 1.0-(xrnd()%11)*0.1;
        if (t) {
            bvs[0] = true;
            v[i] = 0;
            t = false;
            continue;
        }
        // for (int j = m; j < 2085050; ++j) {
        for (int j = m*d; j < 2085050; ++j) {
            if (bvs[j]) { continue; }
            bool f = false;
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    if (bes[abs(j-v[k])]) {
                        f = true;
                        break;
                    }
                }
            }
            if (f) { continue; }
            
            us.clear();
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    if (us.find(abs(j-v[k])) != us.end()) {
                        f = true;
                        break;
                    }
                    us.emplace(abs(j-v[k]));
                }
            }
            
            if (f) { continue; }
            bvs[j] = true;
            for (auto&& k : g[i]) {
                if (v[k] >= 0) {
                    bes[abs(j-v[k])] = true;
                }
            }
            v[i] = j;
            m = max(m, j);
            break;
        }
        
        if (sw.get_milli_time() > 9500) {
            score = 2085050;
            return;
        }
        
    }
    
    ret = v;
    score = m;
}
int main() {
    int N;
    cin >> N;
    int edges;
    cin >> edges;
    StopWatch sw;
    vector<vector<bool> > graph(N,vector<bool>(N,false));
    
    vector< vector<int> > g(N, vector<int>());
    
    
    for(int i = 0; i < edges; i++) {
        int node1,node2;
        cin >> node1 >> node2;
        graph[node1][node2] = true;
        graph[node2][node1] = true;
        g[node1].emplace_back(node2);
        g[node2].emplace_back(node1);
    }
    
    int bestscore;
    vector<int> bestv;
    solve(N, edges, g, bestv, bestscore);
    
    int dt = sw.get_milli_time();
    
    if (dt > 50000) {
        while (sw.get_milli_time() < 9000-dt) {
            int score;
            vector<int> v;
            rndsolve(N, edges, g, v, score);
            if (score < bestscore) {
                bestscore = score;
                bestv = v;
            }
        }
    }
    {
        int cnt = 0;
        vector<int> indexs;
        for(int i = 0; i < N; i++) { indexs.emplace_back(i); }
        sort(indexs.begin(), indexs.end(), [g](const int& a, const int& b) { return g[a].size() > g[b].size(); });
        
        
        while (sw.get_milli_time() < 8000) {
            int score;
            vector<int> v;
            int a = xrnd() % N;
            int b = xrnd() % N;
            swap(indexs[a], indexs[b]);
            rndsolve3(N, edges, g, v, score, indexs, sw);
            
            if (score < bestscore) {
                bestscore = score;
                bestv = v;
            } else {
                swap(indexs[a], indexs[b]);
            }
            cnt += 1;
        }
        while (sw.get_milli_time() < 9500) {
            int score;
            vector<int> v;
            rndsolve4(N, edges, g, v, score, indexs, sw);
            
            if (score < bestscore) {
                bestscore = score;
                bestv = v;
            }
            cnt += 1;
        }
        
    }
    
    
    
    
    pdebug(N, edges, sw.get_milli_time());
    // pdebug(v);
    // pdebug(g);
    output(bestv);
    return 0;
}
