#!/bin/sh
g++ -O2 --std=c++0x -o /workdir/ImageFromBlocks.exe /workdir/ImageFromBlocks.cpp
$@ '/workdir/ImageFromBlocks.exe' > /workdir/result.txt