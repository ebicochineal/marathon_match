#!/bin/sh
g++ -std=gnu++11 -O3 /workdir/ImageFromBlocks.cpp -o /workdir/ImageFromBlocks
echo '/workdir/ImageFromBlocks' > /workdir/command.txt