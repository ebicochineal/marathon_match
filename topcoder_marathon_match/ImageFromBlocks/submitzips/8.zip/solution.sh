#!/bin/sh
g++ --std=c++0x -W -Wall -Wno-sign-compare -O2 -s -pipe -mmmx -msse -msse2 -msse3 -o /workdir/ImageFromBlocks.exe /workdir/ImageFromBlocks.cpp
$@ '/workdir/ImageFromBlocks.exe' > /workdir/result.txt