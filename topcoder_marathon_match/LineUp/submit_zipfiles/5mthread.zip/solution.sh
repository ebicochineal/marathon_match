#!/bin/sh
g++ -std=gnu++11 -pthread -O3 /workdir/LineUp.cpp -o /workdir/LineUp
echo '/workdir/LineUp' > /workdir/command.txt