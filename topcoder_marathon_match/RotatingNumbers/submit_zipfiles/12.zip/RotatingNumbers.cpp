#include <cmath>
#include <string>
#include <array>
#include <vector>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <limits>
#include <queue>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <time.h>
#include <sys/timeb.h>
using namespace std;

template<class F, class S> string in_v_to_str (const pair<F, S> v);
template<class F, class S> string v_to_str (const pair<F, S> v);
string in_v_to_str (const char v) { return "'" + string{v} + "'"; }
string in_v_to_str (const char* v) { return "\"" + string(v) + "\""; }
string in_v_to_str (const string v) { return "\"" + v + "\""; }
template<class T> string in_v_to_str (const T v) { stringstream ss; ss << v; return ss.str(); }
template<class T> string v_to_str (const T v) { stringstream ss; ss << v; return ss.str(); }
template<class T, size_t N> string v_to_str (const array<T, N>& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << in_v_to_str(v[i]) << ", "; } ss << in_v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[]"; } return ss.str(); }
template<class T, size_t N> string v_to_str (const array< array<T, N>, N >& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << v_to_str(v[i]) << ", "; } ss << v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[-]"; } return ss.str(); }
template<class T> string v_to_str (const vector<T>& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << in_v_to_str(v[i]) << ", "; } ss << in_v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[]"; } return ss.str(); }
template<class T> string v_to_str (const vector< vector<T> >& v) { stringstream ss; if (v.size() > 0) { ss << "["; for (int i = 0; i < v.size() - 1; ++i) { ss << v_to_str(v[i]) << ", "; } ss << v_to_str(v[v.size() - 1]) << "]"; } else { ss << "[-]"; } return ss.str(); }
template<class T> string v_to_str (const set<T>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class K, class V> string v_to_str (const map<K, V>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i.first) << " : " << in_v_to_str(i.second) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class T> string v_to_str (const unordered_set<T>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class K, class V> string v_to_str (const unordered_map<K, V>& v) { stringstream ss; int len = v.size(); ss << (v.size() > 0 ? "{" : "{}"); for (auto& i : v) { ss << in_v_to_str(i.first) << " : " << in_v_to_str(i.second) << (len-- > 1 ? ", " : "}"); } return ss.str(); }
template<class F, class S> string in_v_to_str (const pair<F, S> v) { stringstream ss; ss << "<" << v_to_str(v.first) << ", " << v_to_str(v.second) << ">"; return ss.str(); }
template<class F, class S> string v_to_str (const pair<F, S> v) { stringstream ss; ss << "<" << v_to_str(v.first) << ", " << v_to_str(v.second) << ">"; return ss.str(); }
string print () { return ""; }
template<typename F, typename... R> string print (const F& f, const R& ...r) { stringstream ss; ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); } return ss.str(); }

template<typename F, typename... R> void pdebug (const F& f, const R& ...r) {
    stringstream ss;
    ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); }
    cerr << "<cerr>" << ss.str() << "</cerr>" << endl;
}

template<typename F, typename... R> void fdebug (const F& f, const R& ...r) {
    stringstream ss;
    ss << v_to_str(f); if (sizeof...(r) > 0) { ss << " " << print(r...); }
    cerr << "<cerrfile>" << ss.str() << "</cerrfile>" << endl;
}

struct e512pos {
public:
    int x;
    int y;
    e512pos () { this->x = 0; this->y = 0; }
    e512pos (int x, int y) {
        this->x = x;
        this->y = y;
    }
    e512pos operator + (const e512pos& t) { return e512pos(this->x + t.x, this->y + t.y); }
    e512pos operator - (const e512pos& t) { return e512pos(this->x - t.x, this->y - t.y); }
    bool operator == (const e512pos& t) const { return this->x == t.x && this->y == t.y; }
};
namespace std {
    template <> class hash<e512pos> {
    public:
        size_t operator()(const e512pos& t) const{ return hash<int>()(t.x<<16) | hash<int>()(t.y); }
    };
}
ostream& operator << (ostream& os, const e512pos& p) {
    os << "(" << p.x << ", " << p.y << ")";
    return os;
};

class StopWatch {
public:
    int starts;
    int startm;
    int tstarts = 0;
    int tstartm = 0;
    struct timeb timebuffer;
    StopWatch () {
        ftime(&this->timebuffer);
        this->starts = this->timebuffer.time;
        this->startm = this->timebuffer.millitm;
    }
    inline void stop () {
        ftime(&this->timebuffer);
        this->tstarts = this->timebuffer.time;
        this->tstartm = this->timebuffer.millitm;
    }
    inline void resume () {
        ftime(&this->timebuffer);
        this->starts += this->timebuffer.time - this->tstarts;
        this->startm += this->timebuffer.millitm - this->tstartm;
    }
    inline int get_milli_time () {
        ftime(&this->timebuffer);
        return (this->timebuffer.time - this->starts) * 1000 + (this->timebuffer.millitm - this->startm);
    }
};

inline uint32_t xrnd() {
    static uint32_t y = 2463534242;
    y = y ^ (y << 13);
    y = y ^ (y >> 17);
    return y = y ^ (y << 5);
}

class RCSD {
public:
    int x = 0;
    int y = 0;
    int s = 0;
    int d = 0;// R0, L1
    RCSD () {}
    RCSD (int x, int y, int s, int d) {
        this->x = x;
        this->y = y;
        this->s = s;
        this->d = d;
    }
    
    
    
};

int g_flpow[45] = {0, 0, 1, 2, 5, 8, 11, 14, 18, 22, 27, 31, 36, 41, 46, 52, 58, 64, 70, 76, 82, 89, 96, 103, 110, 117, 125, 132, 140, 148, 156, 164, 172, 181, 189, 198, 207, 216, 225, 234, 243, 252, 262, 272, 281};
int g_rgrid[40][40];
bool g_notmove[40][40];

class RotatingNumbers {
public:
    int N, P;
    vector<int> rawgrid;
    StopWatch sw;
    vector<string> findSolution(int N, int P, vector<int> grid) {
        this->sw = StopWatch();
        this->N = N;
        this->P = P;
        this->rawgrid = grid;
        
        
        int cnt = 0;
        
        vector<RCSD> t;
        int bestscore = this->test0(t);
        vector<RCSD> bestret = t;
        while (this->sw.get_milli_time() < 8000) {
            t.clear();
            int tscore = this->test1(t);
            if (tscore < bestscore) {
                bestscore = tscore;
                bestret = t;
            }
        }
        
        while (this->sw.get_milli_time() < 8250 && bestret.size() > 0) {
            auto t = bestret[bestret.size()-1];
            bestret.pop_back();
            int tscore = this->allScore(bestret);
            if (tscore < bestscore) {
                bestscore = tscore;
            } else {
                bestret.emplace_back(t);
            }
        }
        while (this->sw.get_milli_time() < 8500) {
            int x = xrnd() % (this->N - 1);
            int y = xrnd() % (this->N - 1);
            int s = max(2, (int)(xrnd() % (this->N - max(x, y) + 1)));
            int d = xrnd() % 2;
            bestret.emplace_back(x, y, s, d);
            int tscore = this->allScore(bestret);
            if (tscore < bestscore) {
                bestscore = tscore;
            } else {
                bestret.pop_back();
            }
        }
        
        
        
        
        pdebug("N =", N, "P =", P);
        pdebug(this->allScore(bestret));
        
        pdebug(cnt, this->sw.get_milli_time());
        return this->out(bestret);
        
        // vector<RCSD> t;
        // vector<int> g = this->rawgrid;
        // pdebug(g[(this->N-1)+this->N*(this->N-1)]);
        // pdebug(this->freeGreedyMove(g, t, 0, 0, 0, 0, this->N-1, this->N-1));
        // return out(t);
        
    }
    
    int test0 (vector<RCSD>& r) {
        this->gmove01(this->rawgrid, r);
        
        
        
        
        return this->allScore(r);
    }
    
    int test1 (vector<RCSD>& r) {
        vector<int> g = this->rawgrid;
        int c = xrnd() % 5;
        
        for (int i = 0; i < c; ++i) {
            int s = max(2, (int)(xrnd() % (this->N+1)));
            int px = xrnd() % (this->N-s+1);
            int py = xrnd() % (this->N-s+1);
            
            if (xrnd()%2 == 0) {
                this->rotR(px, py, s, g);
                r.emplace_back(px, py, s, 0);
            } else {
                this->rotL(px, py, s, g);
                r.emplace_back(px, py, s, 1);
            }
        }
        int bestscore = this->allScore(r);
        auto bestret = r;
        if (this->N < 5) {
            {
                auto tret = r;
                int score = this->move1(g, tret);
                
                if (score < bestscore) {
                    bestscore = score;
                    bestret = tret;
                }
            }
            {
                auto tret = r;
                int score = this->move2(g, tret);
                if (score < bestscore) {
                    bestscore = score;
                    bestret = tret;
                }
            }
            {
                auto tret = r;
                int score = this->move3(g, tret);
                if (score < bestscore) {
                    bestscore = score;
                    bestret = tret;
                }
            }
            {
                auto tret = r;
                int score = this->move4(g, tret);
                if (score < bestscore) {
                    bestscore = score;
                    bestret = tret;
                }
            }
        }
        {
            auto tret = r;
            int score = this->gmove01(g, tret);
            if (score < bestscore) {
                bestscore = score;
                bestret = tret;
            }
        }
        {
            auto tret = r;
            int score = this->gmove02(g, tret);
            if (score < bestscore) {
                bestscore = score;
                bestret = tret;
            }
        }
        {
            auto tret = r;
            int score = this->gmove03(g, tret);
            if (score < bestscore) {
                bestscore = score;
                bestret = tret;
            }
        }
        {
            auto tret = r;
            int score = this->gmove04(g, tret);
            if (score < bestscore) {
                bestscore = score;
                bestret = tret;
            }
        }
        r = bestret;
        return this->allScore(r);
    }
    
    int move1 (vector<int> grid,vector<RCSD>& v) {
        // vector<int> grid = this->rawgrid;
        
        
        for (int y = 0; y < this->N-1; ++y) {
            for (int x = 0; x < this->N; ++x) {
                int t = y * this->N + x + 1;
                int px = 0;
                int py = 0;
                for (int i = 0; i < this->N * this->N; ++i) {
                    if (grid[i] == t) {
                        px = i % this->N;
                        py = i / this->N;
                        break;
                    }
                }
                
                
                if (py == this->N-1) {
                    while (abs(px - x) > 0) {
                        if (px - x > 0) {
                            this->rotR(px-1, py-1, 2, grid);
                            v.emplace_back(px-1, py-1, 2, 0);
                            px -= 1;
                        } else {
                            this->rotL(px, py-1, 2, grid);
                            v.emplace_back(px, py-1, 2, 1);
                            px += 1;
                        }
                    }
                } else {
                    while (abs(px - x) > 0) {
                        if (px - x > 0) {
                            this->rotL(px-1, py, 2, grid);
                            v.emplace_back(px-1, py, 2, 1);
                            px -= 1;
                        } else {
                            this->rotR(px, py, 2, grid);
                            v.emplace_back(px, py, 2, 0);
                            px += 1;
                        }
                    }
                }
                
                if (px < this->N-1) {
                    while (py - y > 0) {
                        this->rotR(px, py-1, 2, grid);
                        v.emplace_back(px, py-1, 2, 0);
                        py -= 1;
                    }
                } else {
                    while (py - y > 2) {
                        this->rotL(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 1);
                        py -= 1;
                    }
                    
                    if (py - y == 1 && py < this->N - 1) {
                        this->rotR(px-1, py, 2, grid);
                        v.emplace_back(px-1, py, 2, 0);
                        py += 1;
                    }
                    if (py - y > 1) {
                        this->rotR(px-1, py-2, 2, grid);
                        v.emplace_back(px-1, py-2, 2, 0);
                        
                        this->rotL(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 1);
                        
                        this->rotL(px-1, py-2, 2, grid);
                        v.emplace_back(px-1, py-2, 2, 1);
                    }
                }
            }
        }
        
        return this->gridScore(grid);
    }
    int move2 (vector<int> grid,vector<RCSD>& v) {
        // vector<int> grid = this->rawgrid;
        
        for (int x = 0; x < this->N-1; ++x) {
            for (int y = 0; y < this->N; ++y) {
                int t = y * this->N + x + 1;
                int px = 0;
                int py = 0;
                for (int i = 0; i < this->N * this->N; ++i) {
                    if (grid[i] == t) {
                        px = i % this->N;
                        py = i / this->N;
                        break;
                    }
                }
                
                
                if (px == this->N-1) {
                    while (abs(py - y) > 0) {
                        if (py - y > 0) {
                            this->rotL(px-1, py-1, 2, grid);
                            v.emplace_back(px-1, py-1, 2, 1);
                            py -= 1;
                        } else {
                            this->rotR(px-1, py, 2, grid);
                            v.emplace_back(px-1, py, 2, 0);
                            py += 1;
                        }
                    }
                } else {
                    while (abs(py - y) > 0) {
                        if (py - y > 0) {// u
                            this->rotR(px, py-1, 2, grid);
                            v.emplace_back(px, py-1, 2, 0);
                            py -= 1;
                        } else {// d
                            this->rotL(px, py, 2, grid);
                            v.emplace_back(px, py, 2, 1);
                            py += 1;
                        }
                    }
                }
                
                if (py < this->N-1) {// l
                    while (px - x > 0) {
                        this->rotL(px-1, py, 2, grid);
                        v.emplace_back(px-1, py, 2, 1);
                        px -= 1;
                    }
                } else {
                    while (px - x > 2) {
                        this->rotR(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 0);
                        px -= 1;
                    }
                    
                    if (px - x == 1 && px < this->N - 1) {
                        this->rotL(px, py-1, 2, grid);
                        v.emplace_back(px, py-1, 2, 1);
                        px += 1;
                    }
                    if (px - x > 1) {
                        this->rotL(px-2, py-1, 2, grid);
                        v.emplace_back(px-2, py-1, 2, 1);
                        
                        this->rotR(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 0);
                        
                        this->rotR(px-2, py-1, 2, grid);
                        v.emplace_back(px-2, py-1, 2, 0);
                    }
                }
                
                
            }
        }
        
        return this->gridScore(grid);
    }
    
    int move3 (vector<int> grid,vector<RCSD>& v) {
        // vector<int> grid = this->rawgrid;
        int d = min((int)(2+xrnd()%4), this->N);
        
        
        for (int y = 0; y < this->N-d; ++y) {
            for (int x = 0; x < this->N; ++x) {
                int t = y * this->N + x + 1;
                int px = 0;
                int py = 0;
                for (int i = 0; i < this->N * this->N; ++i) {
                    if (grid[i] == t) {
                        px = i % this->N;
                        py = i / this->N;
                        break;
                    }
                }
                
                
                if (py == this->N-1) {
                    while (abs(px - x) > 0) {
                        if (px - x > 0) {
                            this->rotR(px-1, py-1, 2, grid);
                            v.emplace_back(px-1, py-1, 2, 0);
                            px -= 1;
                        } else {
                            this->rotL(px, py-1, 2, grid);
                            v.emplace_back(px, py-1, 2, 1);
                            px += 1;
                        }
                    }
                } else {
                    while (abs(px - x) > 0) {
                        if (px - x > 0) {
                            this->rotL(px-1, py, 2, grid);
                            v.emplace_back(px-1, py, 2, 1);
                            px -= 1;
                        } else {
                            this->rotR(px, py, 2, grid);
                            v.emplace_back(px, py, 2, 0);
                            px += 1;
                        }
                    }
                }
                
                if (px < this->N-1) {
                    while (py - y > 0) {
                        this->rotR(px, py-1, 2, grid);
                        v.emplace_back(px, py-1, 2, 0);
                        py -= 1;
                    }
                } else {
                    while (py - y > 2) {
                        this->rotL(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 1);
                        py -= 1;
                    }
                    
                    if (py - y == 1 && py < this->N - 1) {
                        this->rotR(px-1, py, 2, grid);
                        v.emplace_back(px-1, py, 2, 0);
                        py += 1;
                    }
                    if (py - y > 1) {
                        this->rotR(px-1, py-2, 2, grid);
                        v.emplace_back(px-1, py-2, 2, 0);
                        
                        this->rotL(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 1);
                        
                        this->rotL(px-1, py-2, 2, grid);
                        v.emplace_back(px-1, py-2, 2, 1);
                    }
                }
            }
        }
        
        for (int x = 0; x < this->N-1; ++x) {
            for (int y = this->N-d; y < this->N; ++y) {
                int t = y * this->N + x + 1;
                int px = 0;
                int py = 0;
                for (int i = 0; i < this->N * this->N; ++i) {
                    if (grid[i] == t) {
                        px = i % this->N;
                        py = i / this->N;
                        break;
                    }
                }
                
                
                if (px == this->N-1) {
                    while (abs(py - y) > 0) {
                        if (py - y > 0) {
                            this->rotL(px-1, py-1, 2, grid);
                            v.emplace_back(px-1, py-1, 2, 1);
                            py -= 1;
                        } else {
                            this->rotR(px-1, py, 2, grid);
                            v.emplace_back(px-1, py, 2, 0);
                            py += 1;
                        }
                    }
                } else {
                    while (abs(py - y) > 0) {
                        if (py - y > 0) {// u
                            this->rotR(px, py-1, 2, grid);
                            v.emplace_back(px, py-1, 2, 0);
                            py -= 1;
                        } else {// d
                            this->rotL(px, py, 2, grid);
                            v.emplace_back(px, py, 2, 1);
                            py += 1;
                        }
                    }
                }
                
                if (py < this->N-1) {// l
                    while (px - x > 0) {
                        this->rotL(px-1, py, 2, grid);
                        v.emplace_back(px-1, py, 2, 1);
                        px -= 1;
                    }
                } else {
                    while (px - x > 2) {
                        this->rotR(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 0);
                        px -= 1;
                    }
                    
                    if (px - x == 1 && px < this->N - 1) {
                        this->rotL(px, py-1, 2, grid);
                        v.emplace_back(px, py-1, 2, 1);
                        px += 1;
                    }
                    if (px - x > 1) {
                        this->rotL(px-2, py-1, 2, grid);
                        v.emplace_back(px-2, py-1, 2, 1);
                        
                        this->rotR(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 0);
                        
                        this->rotR(px-2, py-1, 2, grid);
                        v.emplace_back(px-2, py-1, 2, 0);
                    }
                }
                
                
            }
        }
        
        return this->gridScore(grid);
    }
    
    int move4 (vector<int> grid,vector<RCSD>& v) {
        // vector<int> grid = this->rawgrid;
        
        int d = min((int)(2+xrnd()%2), this->N);
        
        for (int x = 0; x < this->N-d; ++x) {
            for (int y = 0; y < this->N; ++y) {
                int t = y * this->N + x + 1;
                int px = 0;
                int py = 0;
                for (int i = 0; i < this->N * this->N; ++i) {
                    if (grid[i] == t) {
                        px = i % this->N;
                        py = i / this->N;
                        break;
                    }
                }
                
                
                if (px == this->N-1) {
                    while (abs(py - y) > 0) {
                        if (py - y > 0) {
                            this->rotL(px-1, py-1, 2, grid);
                            v.emplace_back(px-1, py-1, 2, 1);
                            py -= 1;
                        } else {
                            this->rotR(px-1, py, 2, grid);
                            v.emplace_back(px-1, py, 2, 0);
                            py += 1;
                        }
                    }
                } else {
                    while (abs(py - y) > 0) {
                        if (py - y > 0) {// u
                            this->rotR(px, py-1, 2, grid);
                            v.emplace_back(px, py-1, 2, 0);
                            py -= 1;
                        } else {// d
                            this->rotL(px, py, 2, grid);
                            v.emplace_back(px, py, 2, 1);
                            py += 1;
                        }
                    }
                }
                
                if (py < this->N-1) {// l
                    while (px - x > 0) {
                        this->rotL(px-1, py, 2, grid);
                        v.emplace_back(px-1, py, 2, 1);
                        px -= 1;
                    }
                } else {
                    while (px - x > 2) {
                        this->rotR(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 0);
                        px -= 1;
                    }
                    
                    if (px - x == 1 && px < this->N - 1) {
                        this->rotL(px, py-1, 2, grid);
                        v.emplace_back(px, py-1, 2, 1);
                        px += 1;
                    }
                    if (px - x > 1) {
                        this->rotL(px-2, py-1, 2, grid);
                        v.emplace_back(px-2, py-1, 2, 1);
                        
                        this->rotR(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 0);
                        
                        this->rotR(px-2, py-1, 2, grid);
                        v.emplace_back(px-2, py-1, 2, 0);
                    }
                }
                
                
            }
        }
        
        for (int y = 0; y < this->N-1; ++y) {
            for (int x = this->N-d; x < this->N; ++x) {
                int t = y * this->N + x + 1;
                int px = 0;
                int py = 0;
                for (int i = 0; i < this->N * this->N; ++i) {
                    if (grid[i] == t) {
                        px = i % this->N;
                        py = i / this->N;
                        break;
                    }
                }
                
                
                if (py == this->N-1) {
                    while (abs(px - x) > 0) {
                        if (px - x > 0) {
                            this->rotR(px-1, py-1, 2, grid);
                            v.emplace_back(px-1, py-1, 2, 0);
                            px -= 1;
                        } else {
                            this->rotL(px, py-1, 2, grid);
                            v.emplace_back(px, py-1, 2, 1);
                            px += 1;
                        }
                    }
                } else {
                    while (abs(px - x) > 0) {
                        if (px - x > 0) {
                            this->rotL(px-1, py, 2, grid);
                            v.emplace_back(px-1, py, 2, 1);
                            px -= 1;
                        } else {
                            this->rotR(px, py, 2, grid);
                            v.emplace_back(px, py, 2, 0);
                            px += 1;
                        }
                    }
                }
                
                if (px < this->N-1) {
                    while (py - y > 0) {
                        this->rotR(px, py-1, 2, grid);
                        v.emplace_back(px, py-1, 2, 0);
                        py -= 1;
                    }
                } else {
                    while (py - y > 2) {
                        this->rotL(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 1);
                        py -= 1;
                    }
                    
                    if (py - y == 1 && py < this->N - 1) {
                        this->rotR(px-1, py, 2, grid);
                        v.emplace_back(px-1, py, 2, 0);
                        py += 1;
                    }
                    if (py - y > 1) {
                        this->rotR(px-1, py-2, 2, grid);
                        v.emplace_back(px-1, py-2, 2, 0);
                        
                        this->rotL(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 1);
                        
                        this->rotL(px-1, py-2, 2, grid);
                        v.emplace_back(px-1, py-2, 2, 1);
                    }
                }
            }
        }
        
        return this->gridScore(grid);
    }
    
    
    void pxpySet (int x, int y, int& px, int& py, vector<int>& grid) {
        const int NN = this->N * this->N;
        const int t = y * this->N + x + 1;
        for (int i = 0; i < NN; ++i) {
            if (grid[i] == t) {
                px = i % this->N;
                py = i / this->N;
                return;
            }
        }
    }
    
    
    
    
    
    
    int dist (vector<int>& grid, int& px, int& py) {
        int k = grid[py*this->N+px]-1;
        int kx = k % this->N;
        int ky = k / this->N;
        return (abs(kx-px) + abs(ky - py));
    }
    
    int subGridScore (vector<int>& grid, int& px, int& py, int sgs) {
        const int ex = px + sgs;
        const int ey = py + sgs;
        int r = g_flpow[sgs];
        for (int y = py; y < ey; ++y) {
            for (int x = px; x < ex; ++x) {
                r += this->dist(grid, x, y);
            }
        }
        return r;
    }
    
    // bool isOutSide(int x, int y, int n) {
    //     return (x < 0 || y < 0 || x+n > this->N || y+n > this->N);
    // }
    
    int leftMoveCost1 (vector<int>& grid, int& px, int& py) {
        int rx = px-1;
        int ry = py;
        if (this->isOutSide(rx, ry, 2)) { return 100000; }
        int r = 0;
        r -= this->subGridScore(grid, rx, ry, 2);
        this->rotL(rx, ry, 2, grid);
        r += this->subGridScore(grid, rx, ry, 2);
        this->rotR(rx, ry, 2, grid);
        return r;
    }
    
    int leftMoveCost2 (vector<int>& grid, int& px, int& py) {
        int rx = px-1;
        int ry = py-1;
        if (this->isOutSide(rx, ry, 2)) { return 100000; }
        int r = 0;
        r -= this->subGridScore(grid, rx, ry, 2);
        this->rotR(rx, ry, 2, grid);
        r += this->subGridScore(grid, rx, ry, 2);
        this->rotL(rx, ry, 2, grid);
        return r;
    }
    
    int rightMoveCost1 (vector<int>& grid, int& px, int& py) {
        int rx = px;
        int ry = py;
        if (this->isOutSide(rx, ry, 2)) { return 100000; }
        int r = 0;
        r -= this->subGridScore(grid, rx, ry, 2);
        this->rotR(rx, ry, 2, grid);
        r += this->subGridScore(grid, rx, ry, 2);
        this->rotL(rx, ry, 2, grid);
        return r;
    }
    
    int rightMoveCost2 (vector<int>& grid, int& px, int& py) {
        int rx = px;
        int ry = py-1;
        if (this->isOutSide(rx, ry, 2)) { return 100000; }
        int r = 0;
        r -= this->subGridScore(grid, rx, ry, 2);
        this->rotL(rx, ry, 2, grid);
        r += this->subGridScore(grid, rx, ry, 2);
        this->rotR(rx, ry, 2, grid);
        return r;
    }
    
    void leftMove1 (vector<int>& grid, vector<RCSD>& v, int& px, int& py) {
        int rx = px-1;
        int ry = py;
        this->rotL(rx, ry, 2, grid);
        v.emplace_back(rx, ry, 2, 1);
        px -= 1;
    }
    void leftMove2 (vector<int>& grid, vector<RCSD>& v, int& px, int& py) {
        int rx = px-1;
        int ry = py-1;
        this->rotR(rx, ry, 2, grid);
        v.emplace_back(rx, ry, 2, 0);
        px -= 1;
    }
    void rightMove1 (vector<int>& grid, vector<RCSD>& v, int& px, int& py) {
        int rx = px;
        int ry = py;
        this->rotR(rx, ry, 2, grid);
        v.emplace_back(rx, ry, 2, 0);
        px += 1;
    }
    void rightMove2 (vector<int>& grid, vector<RCSD>& v, int& px, int& py) {
        int rx = px;
        int ry = py-1;
        this->rotL(rx, ry, 2, grid);
        v.emplace_back(rx, ry, 2, 1);
        px += 1;
    }
    
    int upMoveCost1 (vector<int>& grid, int& px, int& py) {
        int rx = px;
        int ry = py-1;
        if (this->isOutSide(rx, ry, 2)) { return 100000; }
        int r = 0;
        r -= this->subGridScore(grid, rx, ry, 2);
        this->rotR(rx, ry, 2, grid);
        r += this->subGridScore(grid, rx, ry, 2);
        this->rotL(rx, ry, 2, grid);
        return r;
    }
    
    int upMoveCost2 (vector<int>& grid, int& px, int& py) {
        int rx = px-1;
        int ry = py-1;
        if (this->isOutSide(rx, ry, 2)) { return 100000; }
        int r = 0;
        r -= this->subGridScore(grid, rx, ry, 2);
        this->rotL(rx, ry, 2, grid);
        r += this->subGridScore(grid, rx, ry, 2);
        this->rotR(rx, ry, 2, grid);
        return r;
    }
    
    void upMove1 (vector<int>& grid, vector<RCSD>& v, int& px, int& py) {
        int rx = px;
        int ry = py-1;
        this->rotR(rx, ry, 2, grid);
        v.emplace_back(rx, ry, 2, 0);
        py -= 1;
    }
    void upMove2 (vector<int>& grid, vector<RCSD>& v, int& px, int& py) {
        int rx = px-1;
        int ry = py-1;
        this->rotL(rx, ry, 2, grid);
        v.emplace_back(rx, ry, 2, 1);
        py -= 1;
    }
    
    int downMoveCost1 (vector<int>& grid, int& px, int& py) {
        int rx = px;
        int ry = py;
        if (this->isOutSide(rx, ry, 2)) { return 100000; }
        int r = 0;
        r -= this->subGridScore(grid, rx, ry, 2);
        this->rotL(rx, ry, 2, grid);
        r += this->subGridScore(grid, rx, ry, 2);
        this->rotR(rx, ry, 2, grid);
        return r;
    }
    
    int downMoveCost2 (vector<int>& grid, int& px, int& py) {
        int rx = px-1;
        int ry = py;
        if (this->isOutSide(rx, ry, 2)) { return 100000; }
        int r = 0;
        r -= this->subGridScore(grid, rx, ry, 2);
        this->rotR(rx, ry, 2, grid);
        r += this->subGridScore(grid, rx, ry, 2);
        this->rotL(rx, ry, 2, grid);
        return r;
    }
    
    void downMove1 (vector<int>& grid, vector<RCSD>& v, int& px, int& py) {
        int rx = px;
        int ry = py;
        this->rotL(rx, ry, 2, grid);
        v.emplace_back(rx, ry, 2, 1);
        py += 1;
    }
    void downMove2 (vector<int>& grid, vector<RCSD>& v, int& px, int& py) {
        int rx = px-1;
        int ry = py;
        this->rotR(rx, ry, 2, grid);
        v.emplace_back(rx, ry, 2, 0);
        py += 1;
    }
    
    
    void lastX (vector<int>& grid, vector<RCSD>& v, int x, int y, int px, int py) {
        int vx = abs(x - px);
        int vy = abs(y - py);
        if (vy == 1) {
            if (px < this->N-1) {
                this->rotL(px, py, 2, grid);
                v.emplace_back(px, py, 2, 1);
            } else {
                this->rotR(px-1, py, 2, grid);
                v.emplace_back(px-1, py, 2, 0);
            }
            
            py += 1;
            vy = 2;
        }
        
        
        for (int i = 2; i < vy; ++i) {
            if (y < py) {// up
                int a = this->upMoveCost1(grid, px, py);
                int b = this->upMoveCost2(grid, px, py);
                if (a < b) {
                    this->upMove1(grid, v, px, py);
                } else {
                    this->upMove2(grid, v, px, py);
                }
            }
        }
        for (int i = 0; i < vx; ++i) {
            int a = this->rightMoveCost1(grid, px, py);
            int b = this->rightMoveCost2(grid, px, py);
            if (a < b) {
                this->rightMove1(grid, v, px, py);
            } else {
                this->rightMove2(grid, v, px, py);
            }
        }
        
        
        this->rotR(px-1, py-2, 2, grid);
        v.emplace_back(px-1, py-2, 2, 0);
        this->rotL(px-1, py-1, 2, grid);
        v.emplace_back(px-1, py-1, 2, 1);
        this->rotL(px-1, py-2, 2, grid);
        v.emplace_back(px-1, py-2, 2, 1);
    }
    
    void lastY (vector<int>& grid, vector<RCSD>& v, int x, int y, int px, int py) {
        
        int vx = abs(x - px);
        int vy = abs(y - py);
        
        if (vx == 1) {// right
            if (py < this->N-1) {
                this->rotR(px, py, 2, grid);
                v.emplace_back(px, py, 2, 0);
            } else {
                this->rotL(px, py-1, 2, grid);
                v.emplace_back(px, py-1, 2, 1);
            }
            px += 1;
            vx = 2;
        }
        
        for (int i = 2; i < vx; ++i) {
            if (x < px) {// left
                int a = this->leftMoveCost1(grid, px, py);
                int b = this->leftMoveCost2(grid, px, py);
                if (a < b) {
                    this->leftMove1(grid, v, px, py);
                } else {
                    this->leftMove2(grid, v, px, py);
                }
            }
        }
        
        for (int i = 0; i < vy; ++i) {// down
            int a = this->downMoveCost1(grid, px, py);
            int b = this->downMoveCost2(grid, px, py);
            if (a < b) {
                this->downMove1(grid, v, px, py);
            } else {
                this->downMove2(grid, v, px, py);
            }
        }
        
        
        
        
        
        this->rotL(px-2, py-1, 2, grid);
        v.emplace_back(px-2, py-1, 2, 1);
        this->rotR(px-1, py-1, 2, grid);
        v.emplace_back(px-1, py-1, 2, 0);
        this->rotR(px-2, py-1, 2, grid);
        v.emplace_back(px-2, py-1, 2, 0);
    }
    
    bool isOutSide(int x, int y, int n) {
        return (x < this->minx || y < this->miny || x+n > this->N || y+n > this->N);
    }
    int minx = 0;
    int miny = 0;
    
    
    
    int gmove01 (vector<int> grid, vector<RCSD>& v) {
        int d = min((int)(2+xrnd()%16), this->N);
        
        for (int y = 0; y < this->N-d; ++y) {
            for (int x = 0; x < this->N; ++x) {
                int px, py;
                this->pxpySet(x, y, px, py, grid);
                this->minx = 0;
                this->miny = y+1;
                if (x == px && y == py) { continue; }
                if (y > py) { continue; }
                if (x == this->N - 1) {
                    this->lastX(grid, v, x, y, px, py);
                    continue;
                }
                
                int vx = abs(x - px);
                int vy = abs(y - py);
                
                if (vy == 0) {
                    this->miny = y;
                    for (int i = 0; i < vx; ++i) {
                        if (x < px) {// left
                            int a = this->leftMoveCost1(grid, px, py);
                            int b = this->leftMoveCost2(grid, px, py);
                            if (a < b) {
                                this->leftMove1(grid, v, px, py);
                            } else {
                                this->leftMove2(grid, v, px, py);
                            }
                        } else {
                            int a = this->rightMoveCost1(grid, px, py);
                            int b = this->rightMoveCost2(grid, px, py);
                            if (a < b) {
                                this->rightMove1(grid, v, px, py);
                            } else {
                                this->rightMove2(grid, v, px, py);
                            }
                        }
                    }
                    continue;
                }
                
                
                this->freeGreedyMove(grid, v, this->minx, this->miny, x, y+1, px, py);
                px = x;
                py = y+1;
                this->upMove1(grid, v, px, py);
            }
        }
        
        for (int x = 0; x < this->N-2; ++x) {
            for (int y = this->N-d; y < this->N; ++y) {
                int px, py;
                
                this->pxpySet(x, y, px, py, grid);
                this->minx = x+1;
                this->miny = this->N-d;
                if (x == px && y == py) { continue; }
                if (x > px) { continue; }
                if (y == this->N - 1) {
                    this->lastY(grid, v, x, y, px, py);
                    continue;
                }
                
                int vx = abs(x - px);
                int vy = abs(y - py);
                
                if (vx == 0) {
                    this->minx = x;
                    for (int i = 0; i < vy; ++i) {
                        if (y - py < 0) {// up
                            int a = this->upMoveCost1(grid, px, py);
                            int b = this->upMoveCost2(grid, px, py);
                            if (a < b) {
                                this->upMove1(grid, v, px, py);
                            } else {
                                this->upMove2(grid, v, px, py);
                            }
                        } else {
                            int a = this->downMoveCost1(grid, px, py);
                            int b = this->downMoveCost2(grid, px, py);
                            if (a < b || px <= x+1) {
                                this->downMove1(grid, v, px, py);
                            } else {
                                this->downMove2(grid, v, px, py);
                            }
                        }
                    }
                    continue;
                }
                
                this->freeGreedyMove(grid, v, this->minx, this->miny, x+1, y, px, py);
                px = x+1;
                py = y;
                this->leftMove1(grid, v, px, py);
                
            }
        }
        
        return this->gridScore(grid);
        
    }
    
    int gmove02 (vector<int> grid, vector<RCSD>& v) {
        int d = min((int)(2+xrnd()%16), this->N);
        
        for (int x = 0; x < this->N-d; ++x) {
            for (int y = 0; y < this->N; ++y) {
                int px, py;
                
                this->pxpySet(x, y, px, py, grid);
                this->minx = x+1;
                this->miny = 0;
                if (x == px && y == py) { continue; }
                if (x > px) { continue; }
                if (y == this->N - 1) {
                    this->lastY(grid, v, x, y, px, py);
                    continue;
                }
                
                int vx = abs(x - px);
                int vy = abs(y - py);
                
                if (vx == 0) {
                    this->minx = x;
                    for (int i = 0; i < vy; ++i) {
                        if (y - py < 0) {// up
                            int a = this->upMoveCost1(grid, px, py);
                            int b = this->upMoveCost2(grid, px, py);
                            if (a < b) {
                                this->upMove1(grid, v, px, py);
                            } else {
                                this->upMove2(grid, v, px, py);
                            }
                        } else {
                            int a = this->downMoveCost1(grid, px, py);
                            int b = this->downMoveCost2(grid, px, py);
                            if (a < b || px <= x+1) {
                                this->downMove1(grid, v, px, py);
                            } else {
                                this->downMove2(grid, v, px, py);
                            }
                        }
                    }
                    continue;
                }
                
                this->freeGreedyMove(grid, v, this->minx, this->miny, x+1, y, px, py);
                px = x+1;
                py = y;
                this->leftMove1(grid, v, px, py);
            }
        }
        
        for (int y = 0; y < this->N-2; ++y) {
            for (int x = this->N-d; x < this->N; ++x) {
                int px, py;
                this->pxpySet(x, y, px, py, grid);
                this->minx = this->N-d;
                this->miny = y+1;
                if (x == px && y == py) { continue; }
                if (y > py) { continue; }
                if (x == this->N - 1) {
                    this->lastX(grid, v, x, y, px, py);
                    continue;
                }
                
                int vx = abs(x - px);
                int vy = abs(y - py);
                
                if (vy == 0) {
                    this->miny = y;
                    for (int i = 0; i < vx; ++i) {
                        if (x < px) {// left
                            int a = this->leftMoveCost1(grid, px, py);
                            int b = this->leftMoveCost2(grid, px, py);
                            if (a < b) {
                                this->leftMove1(grid, v, px, py);
                            } else {
                                this->leftMove2(grid, v, px, py);
                            }
                        } else {
                            int a = this->rightMoveCost1(grid, px, py);
                            int b = this->rightMoveCost2(grid, px, py);
                            if (a < b) {
                                this->rightMove1(grid, v, px, py);
                            } else {
                                this->rightMove2(grid, v, px, py);
                            }
                        }
                    }
                    continue;
                }
                
                this->freeGreedyMove(grid, v, this->minx, this->miny, x, y+1, px, py);
                px = x;
                py = y+1;
                this->upMove1(grid, v, px, py);
            }
        }
        
        return this->gridScore(grid);
    }
    
    int gmove03 (vector<int> grid, vector<RCSD>& v) {
        int d = min((int)(2+xrnd()%16), this->N);
        
        for (int y = 0; y < this->N-d; ++y) {
            for (int x = 0; x < this->N; ++x) {
                int px, py;
                this->pxpySet(x, y, px, py, grid);
                this->minx = 0;
                this->miny = y+1;
                if (x == px && y == py) { continue; }
                if (y > py) { continue; }
                if (x == this->N - 1) {
                    this->lastX(grid, v, x, y, px, py);
                    continue;
                }
                
                int vx = abs(x - px);
                int vy = abs(y - py);
                
                if (vy == 0) {
                    this->miny = y;
                    for (int i = 0; i < vx; ++i) {
                        if (x < px) {// left
                            int a = this->leftMoveCost1(grid, px, py);
                            int b = this->leftMoveCost2(grid, px, py);
                            if (a < b) {
                                this->leftMove1(grid, v, px, py);
                            } else {
                                this->leftMove2(grid, v, px, py);
                            }
                        } else {
                            int a = this->rightMoveCost1(grid, px, py);
                            int b = this->rightMoveCost2(grid, px, py);
                            if (a < b) {
                                this->rightMove1(grid, v, px, py);
                            } else {
                                this->rightMove2(grid, v, px, py);
                            }
                        }
                    }
                    continue;
                }
                
                vy -= 1;
                
                while (vy + vx > 0) {
                    int bestscore = 100000;
                    int best = -1;
                    if (vx > 0) {
                        if (x < px) {// left
                            int a = this->leftMoveCost1(grid, px, py);
                            int b = this->leftMoveCost2(grid, px, py);
                            if (a < b) {
                                if (a < bestscore) {
                                    bestscore = a;
                                    best = 0;
                                }
                            } else {
                                if (b < bestscore) {
                                    bestscore = b;
                                    best = 1;
                                }
                            }
                        } else {
                            int a = this->rightMoveCost1(grid, px, py);
                            int b = this->rightMoveCost2(grid, px, py);
                            if (a < b) {
                                if (a < bestscore) {
                                    bestscore = a;
                                    best = 2;
                                }
                            } else {
                                if (b < bestscore) {
                                    bestscore = b;
                                    best = 3;
                                }
                            }
                        }
                    }
                    if (vy > 0) {
                        if (y < py) {// up
                            int a = this->upMoveCost1(grid, px, py);
                            int b = this->upMoveCost2(grid, px, py);
                            if (a < b) {
                                if (a < bestscore) {
                                    bestscore = a;
                                    best = 4;
                                }
                            } else {
                                if (b < bestscore) {
                                    bestscore = b;
                                    best = 5;
                                }
                            }
                        }
                    }
                    
                    if (best == 0) { this->leftMove1(grid, v, px, py);  vx -= 1; }
                    if (best == 1) { this->leftMove2(grid, v, px, py);  vx -= 1; }
                    if (best == 2) { this->rightMove1(grid, v, px, py); vx -= 1; }
                    if (best == 3) { this->rightMove2(grid, v, px, py); vx -= 1; }
                    if (best == 4) { this->upMove1(grid, v, px, py); vy -= 1; }
                    if (best == 5) { this->upMove2(grid, v, px, py); vy -= 1; }
                    if (best == -1) { break; }
                }
                
                this->upMove1(grid, v, px, py);
                
            }
        }
        
        for (int x = 0; x < this->N-1; ++x) {
            for (int y = this->N-d; y < this->N; ++y) {
                int t = y * this->N + x + 1;
                int px = 0;
                int py = 0;
                for (int i = 0; i < this->N * this->N; ++i) {
                    if (grid[i] == t) {
                        px = i % this->N;
                        py = i / this->N;
                        break;
                    }
                }
                
                
                if (px == this->N-1) {
                    while (abs(py - y) > 0) {
                        if (py - y > 0) {
                            this->rotL(px-1, py-1, 2, grid);
                            v.emplace_back(px-1, py-1, 2, 1);
                            py -= 1;
                        } else {
                            this->rotR(px-1, py, 2, grid);
                            v.emplace_back(px-1, py, 2, 0);
                            py += 1;
                        }
                    }
                } else {
                    while (abs(py - y) > 0) {
                        if (py - y > 0) {// u
                            this->rotR(px, py-1, 2, grid);
                            v.emplace_back(px, py-1, 2, 0);
                            py -= 1;
                        } else {// d
                            this->rotL(px, py, 2, grid);
                            v.emplace_back(px, py, 2, 1);
                            py += 1;
                        }
                    }
                }
                
                if (py < this->N-1) {// l
                    while (px - x > 0) {
                        this->rotL(px-1, py, 2, grid);
                        v.emplace_back(px-1, py, 2, 1);
                        px -= 1;
                    }
                } else {
                    while (px - x > 2) {
                        this->rotR(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 0);
                        px -= 1;
                    }
                    
                    if (px - x == 1 && px < this->N - 1) {
                        this->rotL(px, py-1, 2, grid);
                        v.emplace_back(px, py-1, 2, 1);
                        px += 1;
                    }
                    if (px - x > 1) {
                        this->rotL(px-2, py-1, 2, grid);
                        v.emplace_back(px-2, py-1, 2, 1);
                        
                        this->rotR(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 0);
                        
                        this->rotR(px-2, py-1, 2, grid);
                        v.emplace_back(px-2, py-1, 2, 0);
                    }
                }
            }
        }
        
        
        return this->gridScore(grid);
        
    }
    
    int gmove04 (vector<int> grid, vector<RCSD>& v) {
        int d = min((int)(2+xrnd()%16), this->N);
        
        for (int x = 0; x < this->N-d; ++x) {
            for (int y = 0; y < this->N; ++y) {
                int px, py;
                
                this->pxpySet(x, y, px, py, grid);
                this->minx = x+1;
                this->miny = 0;
                if (x == px && y == py) { continue; }
                if (x > px) { continue; }
                if (y == this->N - 1) {
                    this->lastY(grid, v, x, y, px, py);
                    continue;
                }
                
                int vx = abs(x - px);
                int vy = abs(y - py);
                
                if (vx == 0) {
                    this->minx = x;
                    for (int i = 0; i < vy; ++i) {
                        if (y - py < 0) {// up
                            int a = this->upMoveCost1(grid, px, py);
                            int b = this->upMoveCost2(grid, px, py);
                            if (a < b) {
                                this->upMove1(grid, v, px, py);
                            } else {
                                this->upMove2(grid, v, px, py);
                            }
                        } else {
                            int a = this->downMoveCost1(grid, px, py);
                            int b = this->downMoveCost2(grid, px, py);
                            if (a < b || px <= x+1) {
                                this->downMove1(grid, v, px, py);
                            } else {
                                this->downMove2(grid, v, px, py);
                            }
                        }
                    }
                    continue;
                }
                
                vx -= 1;
                while (vy + vx > 0) {
                    int bestscore = 100000;
                    int best = -1;
                    if (vy > 0) {
                        if (y < py) {// up
                            int a = this->upMoveCost1(grid, px, py);
                            int b = this->upMoveCost2(grid, px, py);
                            if (a < b) {
                                if (a < bestscore) {
                                    bestscore = a;
                                    best = 0;
                                }
                            } else {
                                if (b < bestscore) {
                                    bestscore = b;
                                    best = 1;
                                }
                            }
                        } else {
                            int a = this->downMoveCost1(grid, px, py);
                            int b = this->downMoveCost2(grid, px, py);
                            if (a < b) {
                                if (a < bestscore) {
                                    bestscore = a;
                                    best = 2;
                                }
                            } else {
                                if (b < bestscore) {
                                    bestscore = b;
                                    best = 3;
                                }
                            }
                        }
                    }
                    if (vx > 0) {
                        if (x < px) {// left
                            int a = this->leftMoveCost1(grid, px, py);
                            int b = this->leftMoveCost2(grid, px, py);
                            if (a < b) {
                                if (a < bestscore) {
                                    bestscore = a;
                                    best = 4;
                                }
                            } else {
                                if (b < bestscore) {
                                    bestscore = b;
                                    best = 5;
                                }
                            }
                        }
                    }
                    
                    if (best == 0) { this->upMove1(grid, v, px, py);   vy -= 1; }
                    if (best == 1) { this->upMove2(grid, v, px, py);   vy -= 1; }
                    if (best == 2) { this->downMove1(grid, v, px, py); vy -= 1; }
                    if (best == 3) { this->downMove2(grid, v, px, py); vy -= 1; }
                    if (best == 4) { this->leftMove1(grid, v, px, py); vx -= 1; }
                    if (best == 5) { this->leftMove2(grid, v, px, py); vx -= 1; }
                    if (best == -1) { break; }
                }
                
                this->leftMove1(grid, v, px, py);
                
            }
        }
        
        for (int y = 0; y < this->N-1; ++y) {
            for (int x = this->N-d; x < this->N; ++x) {
                int t = y * this->N + x + 1;
                int px = 0;
                int py = 0;
                for (int i = 0; i < this->N * this->N; ++i) {
                    if (grid[i] == t) {
                        px = i % this->N;
                        py = i / this->N;
                        break;
                    }
                }
                
                
                if (py == this->N-1) {
                    while (abs(px - x) > 0) {
                        if (px - x > 0) {
                            this->rotR(px-1, py-1, 2, grid);
                            v.emplace_back(px-1, py-1, 2, 0);
                            px -= 1;
                        } else {
                            this->rotL(px, py-1, 2, grid);
                            v.emplace_back(px, py-1, 2, 1);
                            px += 1;
                        }
                    }
                } else {
                    while (abs(px - x) > 0) {
                        if (px - x > 0) {
                            this->rotL(px-1, py, 2, grid);
                            v.emplace_back(px-1, py, 2, 1);
                            px -= 1;
                        } else {
                            this->rotR(px, py, 2, grid);
                            v.emplace_back(px, py, 2, 0);
                            px += 1;
                        }
                    }
                }
                
                if (px < this->N-1) {
                    while (py - y > 0) {
                        this->rotR(px, py-1, 2, grid);
                        v.emplace_back(px, py-1, 2, 0);
                        py -= 1;
                    }
                } else {
                    while (py - y > 2) {
                        this->rotL(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 1);
                        py -= 1;
                    }
                    
                    if (py - y == 1 && py < this->N - 1) {
                        this->rotR(px-1, py, 2, grid);
                        v.emplace_back(px-1, py, 2, 0);
                        py += 1;
                    }
                    if (py - y > 1) {
                        this->rotR(px-1, py-2, 2, grid);
                        v.emplace_back(px-1, py-2, 2, 0);
                        
                        this->rotL(px-1, py-1, 2, grid);
                        v.emplace_back(px-1, py-1, 2, 1);
                        
                        this->rotL(px-1, py-2, 2, grid);
                        v.emplace_back(px-1, py-2, 2, 1);
                    }
                }
            }
        }
        return this->gridScore(grid);
    }
    
    void gridFDebug (vector<int>& grid) {
        for (int y = 0; y < this->N; ++y) {
            vector<int> t ;
            for (int x = 0; x < this->N; ++x) {
                t.emplace_back(grid[x+this->N*y]);
            }
            fdebug(t);
        }
        fdebug(" ");
        
        
        
    }
    
    bool freeGreedyMove (vector<int>& grid, vector<RCSD>& v, int l, int u, int x, int y, int px, int py) {
        
        
        this->minx = l;
        this->miny = u;
        if (x == px && y == py) { return true; }
        
        int vx = abs(x - px);
        int vy = abs(y - py);
        
        while (vy + vx > 0) {
            int bestscore = 100000;
            int best = -1;
            int bestsize = 2;
            for (int s = 2; s < 4; ++s) {
                if (vx >= s-1) {
                    if (x < px) {// left
                        int a = this->leftMoveCost1(grid, px, py, s);
                        int b = this->leftMoveCost2(grid, px, py, s);
                        if (a < b) {
                            if (a < bestscore) {
                                bestscore = a;
                                best = 0;
                                bestsize = s;
                            }
                        } else {
                            if (b < bestscore) {
                                bestscore = b;
                                best = 1;
                                bestsize = s;
                            }
                        }
                    } else {
                        int a = this->rightMoveCost1(grid, px, py, s);
                        int b = this->rightMoveCost2(grid, px, py, s);
                        if (a < b) {
                            if (a < bestscore) {
                                bestscore = a;
                                best = 2;
                                bestsize = s;
                            }
                        } else {
                            if (b < bestscore) {
                                bestscore = b;
                                best = 3;
                                bestsize = s;
                            }
                        }
                    }
                }
                if (vy >= s-1) {
                    if (y < py) {// up
                        int a = this->upMoveCost1(grid, px, py, s);
                        int b = this->upMoveCost2(grid, px, py, s);
                        if (a < b) {
                            if (a < bestscore) {
                                bestscore = a;
                                best = 4;
                                bestsize = s;
                            }
                        } else {
                            if (b < bestscore) {
                                bestscore = b;
                                best = 5;
                                bestsize = s;
                            }
                        }
                    } else {
                        int a = this->downMoveCost1(grid, px, py, s);
                        int b = this->downMoveCost2(grid, px, py, s);
                        if (a < b) {
                            if (a < bestscore) {
                                bestscore = a;
                                best = 6;
                                bestsize = s;
                            }
                        } else {
                            if (b < bestscore) {
                                bestscore = b;
                                best = 7;
                                bestsize = s;
                            }
                        }
                    }
                }
            }
            
            
            if (best == 0) { this->leftMove1(grid, v, px, py, bestsize);  vx -= bestsize - 1; }
            if (best == 1) { this->leftMove2(grid, v, px, py, bestsize);  vx -= bestsize - 1; }
            if (best == 2) { this->rightMove1(grid, v, px, py, bestsize); vx -= bestsize - 1; }
            if (best == 3) { this->rightMove2(grid, v, px, py, bestsize); vx -= bestsize - 1; }
            if (best == 4) { this->upMove1(grid, v, px, py, bestsize);    vy -= bestsize - 1; }
            if (best == 5) { this->upMove2(grid, v, px, py, bestsize);    vy -= bestsize - 1; }
            if (best == 6) { this->downMove1(grid, v, px, py, bestsize);  vy -= bestsize - 1; }
            if (best == 7) { this->downMove2(grid, v, px, py, bestsize);  vy -= bestsize - 1; }
            if (best == -1) { return false; }
        }
        
        return true;
    }
    
    // move 2
        int leftMoveCost1 (vector<int>& grid, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px-d;
            int ry = py;
            if (this->isOutSide(rx, ry, s)) { return 100000; }
            int r = 0;
            r -= this->subGridScore(grid, rx, ry, s);
            this->rotL(rx, ry, s, grid);
            r += this->subGridScore(grid, rx, ry, s);
            this->rotR(rx, ry, s, grid);
            return r;
        }
        
        int leftMoveCost2 (vector<int>& grid, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px-d;
            int ry = py-d;
            if (this->isOutSide(rx, ry, s)) { return 100000; }
            int r = 0;
            r -= this->subGridScore(grid, rx, ry, s);
            this->rotR(rx, ry, s, grid);
            r += this->subGridScore(grid, rx, ry, s);
            this->rotL(rx, ry, s, grid);
            return r;
        }
        
        int rightMoveCost1 (vector<int>& grid, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px;
            int ry = py;
            if (this->isOutSide(rx, ry, s)) { return 100000; }
            int r = 0;
            r -= this->subGridScore(grid, rx, ry, s);
            this->rotR(rx, ry, s, grid);
            r += this->subGridScore(grid, rx, ry, s);
            this->rotL(rx, ry, s, grid);
            return r;
        }
        
        int rightMoveCost2 (vector<int>& grid, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px;
            int ry = py-d;
            if (this->isOutSide(rx, ry, s)) { return 100000; }
            int r = 0;
            r -= this->subGridScore(grid, rx, ry, s);
            this->rotL(rx, ry, s, grid);
            r += this->subGridScore(grid, rx, ry, s);
            this->rotR(rx, ry, s, grid);
            return r;
        }
        
        void leftMove1 (vector<int>& grid, vector<RCSD>& v, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px-d;
            int ry = py;
            this->rotL(rx, ry, s, grid);
            v.emplace_back(rx, ry, s, 1);
            px -= d;
        }
        void leftMove2 (vector<int>& grid, vector<RCSD>& v, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px-d;
            int ry = py-d;
            this->rotR(rx, ry, s, grid);
            v.emplace_back(rx, ry, s, 0);
            px -= d;
        }
        void rightMove1 (vector<int>& grid, vector<RCSD>& v, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px;
            int ry = py;
            this->rotR(rx, ry, s, grid);
            v.emplace_back(rx, ry, s, 0);
            px += d;
        }
        void rightMove2 (vector<int>& grid, vector<RCSD>& v, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px;
            int ry = py-d;
            this->rotL(rx, ry, s, grid);
            v.emplace_back(rx, ry, s, 1);
            px += d;
        }
        
        int upMoveCost1 (vector<int>& grid, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px;
            int ry = py-d;
            if (this->isOutSide(rx, ry, s)) { return 100000; }
            int r = 0;
            r -= this->subGridScore(grid, rx, ry, s);
            this->rotR(rx, ry, s, grid);
            r += this->subGridScore(grid, rx, ry, s);
            this->rotL(rx, ry, s, grid);
            return r;
        }
        
        int upMoveCost2 (vector<int>& grid, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px-d;
            int ry = py-d;
            if (this->isOutSide(rx, ry, s)) { return 100000; }
            int r = 0;
            r -= this->subGridScore(grid, rx, ry, s);
            this->rotL(rx, ry, s, grid);
            r += this->subGridScore(grid, rx, ry, s);
            this->rotR(rx, ry, s, grid);
            return r;
        }
        
        void upMove1 (vector<int>& grid, vector<RCSD>& v, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px;
            int ry = py-d;
            this->rotR(rx, ry, s, grid);
            v.emplace_back(rx, ry, s, 0);
            py -= d;
        }
        void upMove2 (vector<int>& grid, vector<RCSD>& v, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px-d;
            int ry = py-d;
            this->rotL(rx, ry, s, grid);
            v.emplace_back(rx, ry, s, 1);
            py -= d;
        }
        
        int downMoveCost1 (vector<int>& grid, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px;
            int ry = py;
            if (this->isOutSide(rx, ry, s)) { return 100000; }
            int r = 0;
            r -= this->subGridScore(grid, rx, ry, s);
            this->rotL(rx, ry, s, grid);
            r += this->subGridScore(grid, rx, ry, s);
            this->rotR(rx, ry, s, grid);
            return r;
        }
        
        int downMoveCost2 (vector<int>& grid, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px-d;
            int ry = py;
            if (this->isOutSide(rx, ry, s)) { return 100000; }
            int r = 0;
            r -= this->subGridScore(grid, rx, ry, s);
            this->rotR(rx, ry, s, grid);
            r += this->subGridScore(grid, rx, ry, s);
            this->rotL(rx, ry, s, grid);
            return r;
        }
        
        void downMove1 (vector<int>& grid, vector<RCSD>& v, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px;
            int ry = py;
            this->rotL(rx, ry, s, grid);
            v.emplace_back(rx, ry, s, 1);
            py += d;
        }
        void downMove2 (vector<int>& grid, vector<RCSD>& v, int& px, int& py, int s) {
            const int d = s - 1;
            int rx = px-d;
            int ry = py;
            this->rotR(rx, ry, s, grid);
            v.emplace_back(rx, ry, s, 0);
            py += d;
        }
    //
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    void rotR (int px, int py, int s, vector<int>& grid) {
        for (int y = 0; y < s; ++y) {
            for (int x = 0; x < s; ++x) {
                g_rgrid[y][x] = grid[(py+y) * this->N + px+x];
            }
        }
        for (int y = 0; y < s; ++y) {
            for (int x = 0; x < s; ++x) {
                grid[(py+y) * this->N + px+x] = g_rgrid[s-x-1][y];
            }
        }
    }
    
    void rotL (int px, int py, int s, vector<int>& grid) {
        for (int y = 0; y < s; ++y) {
            for (int x = 0; x < s; ++x) {
                g_rgrid[y][x] = grid[(py+y) * this->N + px+x];
            }
        }
        for (int y = 0; y < s; ++y) {
            for (int x = 0; x < s; ++x) {
                grid[(py+y) * this->N + px+x] = g_rgrid[x][s-y-1];
            }
        }
    }
    
    int gridScore (vector<int>& grid) {
        int r = 0;
        for (int y = 0; y < this->N; ++y) {
            for (int x = 0; x < this->N; ++x) {
                int k = grid[y*this->N+x]-1;
                int kx = k % this->N;
                int ky = k / this->N;
                r += (abs(kx-x) + abs(ky - y)) * this->P;
            }
        }
        return r;
    }
    
    int allScore (vector<RCSD>& v) {
        vector<int> t = this->rawgrid;
        int r = 0;
        for (auto&& i : v) {
            if (i.s > 0) {
                r += g_flpow[i.s];
                //r += floor(pow(i.s - 1, 1.5f));
                if (i.d == 0) {
                    this->rotR(i.x, i.y, i.s, t);
                } else {
                    this->rotL(i.x, i.y, i.s, t);
                }
            }
        }
        r += this->gridScore(t);
        return r;
    }
    
    void notMoveClear () {
        for (int y = 0; y < 40; ++y) {
            for (int x = 0; x < 40; ++x) {
                g_notmove[y][x] = false;
            }
        }
    }
    
    
    vector<string> out (vector<RCSD> v) {
        vector<string> r;
        for (auto&& i : v) {
            if (i.s > 0) { r.emplace_back(print(i.y, i.x, i.s, (i.d == 0 ? "R" : "L"))); }
        }
        return r;
    }
    
};

int main() {
    RotatingNumbers prog;
    int N;
    int P;
    int num;
    vector<int> grid;
    
    cin >> N;
    cin >> P;
    for (int i=0; i<N*N; i++) {
        cin >> num;
        grid.push_back(num);
    }
    
    vector<string> ret = prog.findSolution(N, P, grid);
    cout << ret.size() << endl;
    for (int i = 0; i < (int)ret.size(); ++i) {
        cout << ret[i] << endl;
    }
    cout.flush();
}